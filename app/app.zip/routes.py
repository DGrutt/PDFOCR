from flask import render_template, flash, redirect, url_for
from app import app
from app.forms import CodeForm

@app.route('/')
@app.route('/index')
def index():
    corpus = {'corpusname': 'Sample Corpus'}
    documents = [
    {
        'docID': {'docname': 'Sample1'},
        'body': 'This is sample text'
    },
    {
        'docID': {'docname': 'Sample2'},
        'body': 'Another sample text'
    }
    ]
    docimage = '/./image.jpg'#fix relative link

    return render_template('index.html', title='home', corpus=corpus, documents=documents, docimage=docimage)

@app.route('/code', methods=['GET', 'POST'] )
def code():
    form = CodeForm()
    if form.validate_on_submit():
        flash('document coded {}'.format(form.relevance.data))
        return redirect(url_for('index'))
    return render_template('code.html', title='Code', form=form)


